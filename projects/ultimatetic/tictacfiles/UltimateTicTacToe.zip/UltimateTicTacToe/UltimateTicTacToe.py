import tkinter
from tkinter import *
from PIL import Image, ImageTk
from tkinter import messagebox 


#make window and title
m = Tk()
m.attributes('-fullscreen', True)
defaultbg = m.cget('bg')
title = Label(m, text='Ultimate Tic Tac Toe!')
#set heights
m.update_idletasks()
title.update_idletasks()
mHeight = m.winfo_height()
titleHeight = title.winfo_height()
appHeight = mHeight-titleHeight-30
#create main board
canvas = Canvas(m, width=appHeight, height=appHeight)#, bg="darkred")
title.pack()
canvas.pack()
canvas_height = appHeight - 10
canvas_width = appHeight - 10
canvas.create_line(5, ((2 * canvas_height) / 3) + 5, canvas_width + 5, ((2 * canvas_height) / 3) + 5, width=3)
canvas.create_line(5, (canvas_height / 3) + 5, canvas_width + 5, (canvas_height / 3) + 5, width=3)
canvas.create_line(((2 * canvas_width) / 3) + 5, 5, ((2 * canvas_width) / 3) + 5, canvas_height + 5, width=3)
canvas.create_line(((canvas_width / 3) + 5), 5, (canvas_width / 3) + 5, canvas_height + 5, width=3)
#miniDemo
mini = Canvas(m, width=100, height=100)
mini.place(x=120, y=110)
demoLabel = Label(m, text="Active Square")
demoLabel.place(x=120, y=80)
mini0 = Canvas(mini, width=30, height=30, highlightthickness=2, highlightbackground="black", bg="darkgray")
mini0.place(x=0, y=0)
mini1 = Canvas(mini, width=30, height=30, highlightthickness=2, highlightbackground="black", bg="darkgray")
mini1.place(x=30, y=0)
mini2 = Canvas(mini, width=30, height=30, highlightthickness=2, highlightbackground="black", bg="darkgray")
mini2.place(x=60, y=0)
mini3 = Canvas(mini, width=30, height=30, highlightthickness=2, highlightbackground="black", bg="darkgray")
mini3.place(x=0, y=30)
mini4 = Canvas(mini, width=30, height=30, highlightthickness=2, highlightbackground="black", bg="darkgray")
mini4.place(x=30, y=30)
mini5 = Canvas(mini, width=30, height=30, highlightthickness=2, highlightbackground="black", bg="darkgray")
mini5.place(x=60, y=30)
mini6 = Canvas(mini, width=30, height=30, highlightthickness=2, highlightbackground="black", bg="darkgray")
mini6.place(x=0, y=60)
mini7 = Canvas(mini, width=30, height=30, highlightthickness=2, highlightbackground="black", bg="darkgray")
mini7.place(x=30, y=60)
mini8 = Canvas(mini, width=30, height=30, highlightthickness=2, highlightbackground="black", bg="darkgray")
mini8.place(x=60, y=60)

#dynamic squareWidth abd vars ig
squareWidth = (appHeight/3) - 8
miniSquareWidth = (squareWidth/3) - 5
Ximage = Image.open("X.png")
Xresize = Ximage.resize((int(miniSquareWidth - 3),int(miniSquareWidth - 3)), Image.ANTIALIAS)
Xphoto = ImageTk.PhotoImage(Xresize)
Xresize = Ximage.resize((int(squareWidth - 3),int(squareWidth - 3)), Image.ANTIALIAS)
largeXphoto = ImageTk.PhotoImage(Xresize)
Oimage = Image.open("O.png")
Oresize = Oimage.resize((int(miniSquareWidth - 3),int(miniSquareWidth - 3)), Image.ANTIALIAS)
Ophoto = ImageTk.PhotoImage(Oresize)
Oresize = Oimage.resize((int(squareWidth - 3),int(squareWidth - 3)), Image.ANTIALIAS)
largeOphoto = ImageTk.PhotoImage(Oresize)
Noneimage = Image.open("Nothing.png")
Noneresize = Noneimage.resize((int(miniSquareWidth - 3),int(miniSquareWidth - 3)), Image.ANTIALIAS)
Nonephoto = ImageTk.PhotoImage(Noneresize)
whosTurn = 'X'
isSquareWon = False

def isButton(button):
	if type(button) == type(xButton):
		return True

#functions
def TicTacToeWin(array):
	if isButton(array[0]):
		if array[0].cget("image") == array[1].cget("image") and array[0].cget("image") == array[2].cget("image") and array[0].cget("image") != noneButton.cget("image"):
			return array[0].cget("image")
		elif array[3].cget("image") == array[4].cget("image") and array[3].cget("image") == array[5].cget("image") and array[3].cget("image") != noneButton.cget("image"):
			return array[3].cget("image")
		elif array[6].cget("image") == array[7].cget("image") and array[6].cget("image") == array[8].cget("image") and array[6].cget("image") != noneButton.cget("image"):
			return array[6].cget("image")
		elif array[0].cget("image") == array[3].cget("image") and array[0].cget("image") == array[6].cget("image") and array[0].cget("image") != noneButton.cget("image"):
			return array[0].cget("image")
		elif array[1].cget("image") == array[4].cget("image") and array[1].cget("image") == array[7].cget("image") and array[1].cget("image") != noneButton.cget("image"):
			return array[1].cget("image")
		elif array[2].cget("image") == array[5].cget("image") and array[2].cget("image") == array[8].cget("image") and array[2].cget("image") != noneButton.cget("image"):
			return array[2].cget("image")
		elif array[0].cget("image") == array[4].cget("image") and array[0].cget("image") == array[8].cget("image") and array[0].cget("image") != noneButton.cget("image"):
			return array[0].cget("image")
		elif array[2].cget("image") == array[4].cget("image") and array[2].cget("image") == array[6].cget("image") and array[2].cget("image") != noneButton.cget("image"):
			return array[2].cget("image")
		else:
			return noneButton.cget("image")

def checkWinMini(board):
	squareArray = board.winfo_children()
	winningSquare = TicTacToeWin(squareArray)
	if (winningSquare == xButton.cget("image") or winningSquare == oButton.cget("image")):
		for child in board.winfo_children():
			child.destroy()
		if (winningSquare == xButton.cget("image")):
			winner = Button(board, width=squareWidth, height=squareWidth, image=largeXphoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0)
		elif (winningSquare == oButton.cget("image")):
			winner = Button(board, width=squareWidth, height=squareWidth, image=largeOphoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0)	
		winner.place(x=0,y=0)
	
def checkBigSolution(array, s1, s2, s3):
	if len(array[s1]) == 1 and len(array[s2]) == 1 and len(array[s3]) == 1:
		if array[s1][0].cget("image") == array[s2][0].cget("image") and array[s1][0].cget("image") == array[s3][0].cget("image"):
			return True
def checkWinBig():
	bigSquare0 = board0.winfo_children()
	bigSquare1 = board1.winfo_children()
	bigSquare2 = board2.winfo_children()
	bigSquare3 = board3.winfo_children()
	bigSquare4 = board4.winfo_children()
	bigSquare5 = board5.winfo_children()
	bigSquare6 = board6.winfo_children()
	bigSquare7 = board7.winfo_children()
	bigSquare8 = board8.winfo_children()
	squareArray = [bigSquare0, bigSquare1, bigSquare2, bigSquare3, bigSquare4, bigSquare5, bigSquare6, bigSquare7, bigSquare8]
	if (checkBigSolution(squareArray, 0,1,2)):
		if squareArray[0][0].cget("image") == largeXButton.cget("image"):
			messagebox.showinfo("Game Over!", "X Wins!")
		elif squareArray[0][0].cget("image") == largeOButton.cget("image"):
			messagebox.showinfo("Game Over!", "O Wins!")
	if (checkBigSolution(squareArray, 3,4,5)):
		if squareArray[3][0].cget("image") == largeXButton.cget("image"):
			messagebox.showinfo("Game Over!", "X Wins!")
		elif squareArray[3][0].cget("image") == largeOButton.cget("image"):
			messagebox.showinfo("Game Over!", "O Wins!")		
	if (checkBigSolution(squareArray, 6,7,8)):
		if squareArray[6][0].cget("image") == largeXButton.cget("image"):
			messagebox.showinfo("Game Over!", "X Wins!")
		elif squareArray[6][0].cget("image") == largeOButton.cget("image"):
			messagebox.showinfo("Game Over!", "O Wins!")
	if (checkBigSolution(squareArray, 0,3,6)):
		if squareArray[0][0].cget("image") == largeXButton.cget("image"):
			messagebox.showinfo("Game Over!", "X Wins!")
		elif squareArray[0][0].cget("image") == largeOButton.cget("image"):
			messagebox.showinfo("Game Over!", "O Wins!")
	if (checkBigSolution(squareArray, 1,4,7)):
		if squareArray[1][0].cget("image") == largeXButton.cget("image"):
			messagebox.showinfo("Game Over!", "X Wins!")
		elif squareArray[1][0].cget("image") == largeOButton.cget("image"):
			messagebox.showinfo("Game Over!", "O Wins!")
	if (checkBigSolution(squareArray, 2,5,8)):
		if squareArray[2][0].cget("image") == largeXButton.cget("image"):
			messagebox.showinfo("Game Over!", "X Wins!")
		elif squareArray[2][0].cget("image") == largeOButton.cget("image"):
			messagebox.showinfo("Game Over!", "O Wins!")
	if (checkBigSolution(squareArray, 0,4,8)):
		if squareArray[0][0].cget("image") == largeXButton.cget("image"):
			messagebox.showinfo("Game Over!", "X Wins!")
		elif squareArray[0][0].cget("image") == largeOButton.cget("image"):
			messagebox.showinfo("Game Over!", "O Wins!")
	if (checkBigSolution(squareArray, 2,4,6)):
		if squareArray[2][0].cget("image") == largeXButton.cget("image"):
			messagebox.showinfo("Game Over!", "X Wins!")
		elif squareArray[2][0].cget("image") == largeOButton.cget("image"):
			messagebox.showinfo("Game Over!", "O Wins!")
	allSquaresSolved = True
	for square in squareArray:
		if len(square) != 1:
			allSquaresSolved = False
	if allSquaresSolved == True:
		messagebox.showinfo("Game Over!", "It's a tie!")
			

def swapTurn():
	global whosTurn
	if whosTurn == 'X':
		whosTurn = 'O'
		oButton.config(state="normal")
		xButton.config(state="disabled")
		return
	elif whosTurn == 'O':
		whosTurn = 'X'
		xButton.config(state="normal")
		oButton.config(state="disabled")
		return
def miniBoxCheck(activeBox):
	for child in mini.winfo_children():
		child.config(bg=defaultbg)
		if child == activeBox or isSquareWon == True:
			child.config(bg='darkgray')
def bigBoxCheck(activeBox):
	global isSquareWon
	for child in canvas.winfo_children():
		if (len(activeBox.winfo_children()) != 1):
			isSquareWon = False
			if child != activeBox:
				for square in child.winfo_children():
					if square.cget("image") != largeOButton.cget("image") and square.cget("image") != largeXButton.cget("image"):
						square.config(state="disabled")
			if child == activeBox:
				for square in child.winfo_children():
					square.config(state="normal")
		else:
			isSquareWon = True
			for square in child.winfo_children():
				square.config(state="normal")
def setXorO(XorO, squareClicked, newSquareID, miniSquareID):
	buttonx = squareClicked.winfo_x()
	buttony = squareClicked.winfo_y()
	whichOne = Nonephoto
	if XorO == 'X':
		whichOne = Xphoto
	elif XorO == 'O':
		whichOne = Ophoto
	else:
		whichOne = NonePhoto
	#squareClicked.destroy()
	#squareClicked = Button(squareClicked.master, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=whichOne, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0) #, command=lambda: setXorO(whosTurn, squareClicked))
	#squareClicked.place(x=buttonx, y=buttony)
	squareClicked.config(width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=whichOne, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=returnSmth	)
	checkWinMini(squareClicked.master)
	checkWinBig()
	bigBoxCheck(newSquareID)
	miniBoxCheck(miniSquareID)
	swapTurn()
def buttonX():
	global whosTurn
	whosTurn = 'X'
def buttonO():
	global whosTurn
	whosTurn = 'O'
def returnSmth():
	return

#X or O button
playerLabel = Label(m, text="Who's Turn?")
playerLabel.place(x=1.15*(appHeight/6) - 15, y=(appHeight/2) - 30)
xButton = Button(m, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Xphoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0)
xButton.place(x=.65*(appHeight/6), y=(appHeight/2))	
oButton = Button(m, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Ophoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, state="disabled")
oButton.place(x=1.45*(appHeight/6), y=(appHeight/2))
noneButton = Button(m, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0)
largeXButton = Button(m, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=largeXphoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0)
largeOButton = Button(m, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=largeOphoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0)
#create board0
board0 = Canvas(canvas, width=squareWidth, height=squareWidth)#, bg="red")
board0.place(x=5,y=5)
board0_height = squareWidth
board0_width = squareWidth
board0.create_line(5, ((2 * board0_height) / 3) + 5, board0_width + 5, ((2 * board0_height) / 3) + 5)
board0.create_line(5, (board0_height / 3) + 5, board0_width + 5, (board0_height / 3) + 5)
board0.create_line(((2 * board0_width) / 3) + 5, 5, ((2 * board0_width) / 3) + 5, board0_height + 5)
board0.create_line(((board0_width / 3) + 5), 5, (board0_width / 3) + 5, board0_height + 5)
#create squares of board0
square00 = Button(board0, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square00, board0, mini0))
square00.place(x=5, y=7)
square01 = Button(board0, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square01, board1, mini1))
square01.place(x=(squareWidth/3) + 6, y=7)
square02 = Button(board0, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square02, board2, mini2))
square02.place(x=2*(squareWidth/3) + 7, y=7)
square03 = Button(board0, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square03, board3, mini3))
square03.place(x=5, y=(squareWidth/3) + 8)
square04 = Button(board0, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square04, board4, mini4))
square04.place(x=(squareWidth/3) + 6, y=(squareWidth/3) + 8)
square05 = Button(board0, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square05, board5, mini5))
square05.place(x=2*(squareWidth/3) + 7, y=(squareWidth/3) + 8)
square06 = Button(board0, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square06, board6, mini6))
square06.place(x=5, y=2*(squareWidth/3) + 7)
square07 = Button(board0, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square07, board7, mini7))
square07.place(x=(squareWidth/3) + 6, y=2*(squareWidth/3) + 7)
square08 = Button(board0, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square08, board8, mini8))
square08.place(x=2*(squareWidth/3) + 7, y=2*(squareWidth/3) + 7)
#create board1
board1 = Canvas(canvas, width=squareWidth - 3, height=squareWidth)#, bg="blue")
board1.place(x=(appHeight/3) + 5,y=5)
board1_height = squareWidth
board1_width = squareWidth - 3
board1.create_line(5, ((2 * board1_height) / 3) + 5, board1_width + 5, ((2 * board1_height) / 3) + 5)
board1.create_line(5, (board1_height / 3) + 5, board1_width + 5, (board1_height / 3) + 5)
board1.create_line(((2 * board1_width) / 3) + 5, 5, ((2 * board1_width) / 3) + 5, board1_height + 5)
board1.create_line(((board1_width / 3) + 3), 5, (board1_width / 3) + 3, board1_height + 5)
#create squares of board1
square10 = Button(board1, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square10, board0, mini0))
square10.place(x=3, y=7)
square11 = Button(board1, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square11, board1, mini1))
square11.place(x=(squareWidth/3) + 4, y=7)
square12 = Button(board1, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square12, board2, mini2))
square12.place(x=2*(squareWidth/3) + 7, y=7)
square13 = Button(board1, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square13, board3, mini3))
square13.place(x=3, y=(squareWidth/3) + 8)
square14 = Button(board1, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square14, board4, mini4))
square14.place(x=(squareWidth/3) + 4, y=(squareWidth/3) + 8)
square15 = Button(board1, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square15, board5, mini5))
square15.place(x=2*(squareWidth/3) + 7, y=(squareWidth/3) + 8)
square16 = Button(board1, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square16, board6, mini6))
square16.place(x=3, y=2*(squareWidth/3) + 7)
square17 = Button(board1, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square17, board7, mini7))
square17.place(x=(squareWidth/3) + 4, y=2*(squareWidth/3) + 7)
square18 = Button(board1, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square18, board8, mini8))
square18.place(x=2*(squareWidth/3) + 7, y=2*(squareWidth/3) + 7)
#create board2
board2 = Canvas(canvas, width=squareWidth, height=squareWidth)#, bg="green")
board2.place(x=2*(appHeight/3) + 2,y=5)
board2_height = squareWidth
board2_width = squareWidth
board2.create_line(5, ((2 * board2_height) / 3) + 5, board2_width + 5, ((2 * board2_height) / 3) + 5)
board2.create_line(5, (board2_height / 3) + 5, board2_width + 5, (board2_height / 3) + 5)
board2.create_line(((2 * board2_width) / 3) + 5, 5, ((2 * board2_width) / 3) + 5, board2_height + 5)
board2.create_line(((board2_width / 3) + 5), 5, (board2_width / 3) + 5, board2_height + 5)
#create squares of board2
square20 = Button(board2, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square20, board0, mini0))
square20.place(x=5, y=7)
square21 = Button(board2, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square21, board1, mini1))
square21.place(x=(squareWidth/3) + 6, y=7)
square22 = Button(board2, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square22, board2, mini2))
square22.place(x=2*(squareWidth/3) + 7, y=7)
square23 = Button(board2, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square23, board3, mini3))
square23.place(x=5, y=(squareWidth/3) + 8)
square24 = Button(board2, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square24, board4, mini4))
square24.place(x=(squareWidth/3) + 6, y=(squareWidth/3) + 8)
square25 = Button(board2, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square25, board5, mini5))
square25.place(x=2*(squareWidth/3) + 7, y=(squareWidth/3) + 8)
square26 = Button(board2, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square26, board6, mini6))
square26.place(x=5, y=2*(squareWidth/3) + 7)
square27 = Button(board2, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square27, board7, mini7))
square27.place(x=(squareWidth/3) + 6, y=2*(squareWidth/3) + 7)
square28 = Button(board2, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square28, board8, mini8))
square28.place(x=2*(squareWidth/3) + 7, y=2*(squareWidth/3) + 7)
#create board3
board3 = Canvas(canvas, width=squareWidth, height=squareWidth - 3)#, bg="orange")
board3.place(x=5,y=(appHeight/3) + 5)
board3_height = squareWidth - 3
board3_width = squareWidth
board3.create_line(5, ((2 * board3_height) / 3) + 5, board3_width + 5, ((2 * board3_height) / 3) + 5)
board3.create_line(5, (board3_height / 3) + 5, board3_width + 5, (board3_height / 3) + 5)
board3.create_line(((2 * board3_width) / 3) + 5, 5, ((2 * board3_width) / 3) + 5, board3_height + 5)
board3.create_line(((board3_width / 3) + 5), 5, (board3_width / 3) + 5, board3_height + 5)
#create squares of board3
square30 = Button(board3, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square30, board0, mini0))
square30.place(x=5, y=7)
square31 = Button(board3, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square31, board1, mini1))
square31.place(x=(squareWidth/3) + 6, y=7)
square32 = Button(board3, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square32, board2, mini2))
square32.place(x=2*(squareWidth/3) + 7, y=7)
square33 = Button(board3, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square33, board3, mini3))
square33.place(x=5, y=(squareWidth/3) + 6)
square34 = Button(board3, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square34, board4, mini4))
square34.place(x=(squareWidth/3) + 6, y=(squareWidth/3) + 6)
square35 = Button(board3, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square35, board5, mini5))
square35.place(x=2*(squareWidth/3) + 7, y=(squareWidth/3) + 6)
square36 = Button(board3, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square36, board6, mini6))
square36.place(x=5, y=2*(squareWidth/3) + 7)
square37 = Button(board3, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square37, board7, mini7))
square37.place(x=(squareWidth/3) + 6, y=2*(squareWidth/3) + 7)
square38 = Button(board3, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square38, board8, mini8))
square38.place(x=2*(squareWidth/3) + 7, y=2*(squareWidth/3) + 7)
#create board4
board4 = Canvas(canvas, width=squareWidth - 3, height=squareWidth - 3)#, bg="yellow")
board4.place(x=(appHeight/3) + 5,y=(appHeight/3) + 5)
board4_height = squareWidth - 3
board4_width = squareWidth - 3
board4.create_line(5, ((2 * board4_height) / 3) + 5, board4_width + 5, ((2 * board4_height) / 3) + 5)
board4.create_line(5, (board4_height / 3) + 5, board4_width + 5, (board4_height / 3) + 5)
board4.create_line(((2 * board4_width) / 3) + 5, 5, ((2 * board4_width) / 3) + 5, board4_height + 5)
board4.create_line(((board4_width / 3) + 3), 5, (board4_width / 3) + 3, board4_height + 5)
#create squares of board4
square40 = Button(board4, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square40, board0, mini0))
square40.place(x=3, y=7)
square41 = Button(board4, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square41, board1, mini1))
square41.place(x=(squareWidth/3) + 4, y=7)
square42 = Button(board4, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square42, board2, mini2))
square42.place(x=2*(squareWidth/3) + 7, y=7)
square43 = Button(board4, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square43, board3, mini3))
square43.place(x=3, y=(squareWidth/3) + 6)
square44 = Button(board4, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square44, board4, mini4))
square44.place(x=(squareWidth/3) + 4, y=(squareWidth/3) + 6)
square45 = Button(board4, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square45, board5, mini5))
square45.place(x=2*(squareWidth/3) + 7, y=(squareWidth/3) + 6)
square46 = Button(board4, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square46, board6, mini6))
square46.place(x=3, y=2*(squareWidth/3) + 7)
square47 = Button(board4, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square47, board7, mini7))
square47.place(x=(squareWidth/3) + 4, y=2*(squareWidth/3) + 7)
square48 = Button(board4, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square48, board8, mini8))
square48.place(x=2*(squareWidth/3) + 7, y=2*(squareWidth/3) + 7)
#create board5
board5 = Canvas(canvas, width=squareWidth, height=squareWidth - 3)#, bg="purple")
board5.place(x=2*(appHeight/3) + 2,y=(appHeight/3) + 5)
board5_height = squareWidth - 3
board5_width = squareWidth
board5.create_line(5, ((2 * board5_height) / 3) + 5, board5_width + 5, ((2 * board5_height) / 3) + 5)
board5.create_line(5, (board5_height / 3) + 5, board5_width + 5, (board5_height / 3) + 5)
board5.create_line(((2 * board5_width) / 3) + 5, 5, ((2 * board5_width) / 3) + 5, board5_height + 5)
board5.create_line(((board5_width / 3) + 5), 5, (board5_width / 3) + 5, board5_height + 5)
#create squares of board5
square50 = Button(board5, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square50, board0, mini0))
square50.place(x=5, y=7)
square51 = Button(board5, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square51, board1, mini1))
square51.place(x=(squareWidth/3) + 6, y=7)
square52 = Button(board5, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square52, board2, mini2))
square52.place(x=2*(squareWidth/3) + 7, y=7)
square53 = Button(board5, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square53, board3, mini3))
square53.place(x=5, y=(squareWidth/3) + 6)
square54 = Button(board5, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square54, board4, mini4))
square54.place(x=(squareWidth/3) + 6, y=(squareWidth/3) + 6)
square55 = Button(board5, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square55, board5, mini5))
square55.place(x=2*(squareWidth/3) + 7, y=(squareWidth/3) + 6)
square56 = Button(board5, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square56, board6, mini6))
square56.place(x=5, y=2*(squareWidth/3) + 7)
square57 = Button(board5, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square57, board7, mini7))
square57.place(x=(squareWidth/3) + 6, y=2*(squareWidth/3) + 7)
square58 = Button(board5, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square58, board8, mini8))
square58.place(x=2*(squareWidth/3) + 7, y=2*(squareWidth/3) + 7)
#create board6
board6 = Canvas(canvas, width=squareWidth, height=squareWidth)#, bg="pink")
board6.place(x=5,y=2*(appHeight/3) + 2)
board6_height = squareWidth
board6_width = squareWidth
board6.create_line(5, ((2 * board6_height) / 3) + 5, board6_width + 5, ((2 * board6_height) / 3) + 5)
board6.create_line(5, (board6_height / 3) + 5, board6_width + 5, (board6_height / 3) + 5)
board6.create_line(((2 * board6_width) / 3) + 5, 5, ((2 * board6_width) / 3) + 5, board6_height + 5)
board6.create_line(((board6_width / 3) + 5), 5, (board6_width / 3) + 5, board6_height + 5)
#create squares of board6
square60 = Button(board6, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square60, board0, mini0))
square60.place(x=5, y=7)
square61 = Button(board6, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square61, board1, mini1))
square61.place(x=(squareWidth/3) + 6, y=7)
square62 = Button(board6, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square62, board2, mini2))
square62.place(x=2*(squareWidth/3) + 7, y=7)
square63 = Button(board6, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square63, board3, mini3))
square63.place(x=5, y=(squareWidth/3) + 8)
square64 = Button(board6, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square64, board4, mini4))
square64.place(x=(squareWidth/3) + 6, y=(squareWidth/3) + 8)
square65 = Button(board6, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square65, board5, mini5))
square65.place(x=2*(squareWidth/3) + 7, y=(squareWidth/3) + 8)
square66 = Button(board6, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square66, board6, mini6))
square66.place(x=5, y=2*(squareWidth/3) + 7)
square67 = Button(board6, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square67, board7, mini7))
square67.place(x=(squareWidth/3) + 6, y=2*(squareWidth/3) + 7)
square68 = Button(board6, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square68, board8, mini8))
square68.place(x=2*(squareWidth/3) + 7, y=2*(squareWidth/3) + 7)
#create board7
board7 = Canvas(canvas, width=squareWidth - 3, height=squareWidth)#, bg="darkgray")
board7.place(x=(appHeight/3) + 5,y=2*(appHeight/3) + 2)
board7_height = squareWidth
board7_width = squareWidth - 3
board7.create_line(5, ((2 * board7_height) / 3) + 5, board7_width + 5, ((2 * board7_height) / 3) + 5)
board7.create_line(5, (board7_height / 3) + 5, board7_width + 5, (board7_height / 3) + 5)
board7.create_line(((2 * board7_width) / 3) + 5, 5, ((2 * board7_width) / 3) + 5, board7_height + 5)
board7.create_line(((board7_width / 3) + 3), 5, (board7_width / 3) + 3, board7_height + 5)
#create squares of board7
square70 = Button(board7, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square70, board0, mini0))
square70.place(x=3, y=7)
square71 = Button(board7, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square71, board1, mini1))
square71.place(x=(squareWidth/3) + 4, y=7)
square72 = Button(board7, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square72, board2, mini2))
square72.place(x=2*(squareWidth/3) + 7, y=7)
square73 = Button(board7, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square73, board3, mini3))
square73.place(x=3, y=(squareWidth/3) + 8)
square74 = Button(board7, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square74, board4, mini4))
square74.place(x=(squareWidth/3) + 4, y=(squareWidth/3) + 8)
square75 = Button(board7, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square75, board5, mini5))
square75.place(x=2*(squareWidth/3) + 7, y=(squareWidth/3) + 8)
square76 = Button(board7, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square76, board6, mini6))
square76.place(x=3, y=2*(squareWidth/3) + 7)
square77 = Button(board7, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square77, board7, mini7))
square77.place(x=(squareWidth/3) + 4, y=2*(squareWidth/3) + 7)
square78 = Button(board7, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square78, board8, mini8))
square78.place(x=2*(squareWidth/3) + 7, y=2*(squareWidth/3) + 7)
#create board8
board8 = Canvas(canvas, width=squareWidth, height=squareWidth)#, bg="brown")
board8.place(x=2*(appHeight/3) + 2,y=2*(appHeight/3) + 2)
board8_height = squareWidth
board8_width = squareWidth
board8.create_line(5, ((2 * board8_height) / 3) + 5, board8_width + 5, ((2 * board8_height) / 3) + 5)
board8.create_line(5, (board8_height / 3) + 5, board8_width + 5, (board8_height / 3) + 5)
board8.create_line(((2 * board8_width) / 3) + 5, 5, ((2 * board8_width) / 3) + 5, board8_height + 5)
board8.create_line(((board8_width / 3) + 5), 5, (board8_width / 3) + 5, board8_height + 5)
#create squares of board8
square80 = Button(board8, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square80, board0, mini0))
square80.place(x=5, y=7)
square81 = Button(board8, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square81, board1, mini1))
square81.place(x=(squareWidth/3) + 6, y=7)
square82 = Button(board8, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square82, board2, mini2))
square82.place(x=2*(squareWidth/3) + 7, y=7)
square83 = Button(board8, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square83, board3, mini3))
square83.place(x=5, y=(squareWidth/3) + 8)
square84 = Button(board8, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square84, board4, mini4))
square84.place(x=(squareWidth/3) + 6, y=(squareWidth/3) + 8)
square85 = Button(board8, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square85, board5, mini5))
square85.place(x=2*(squareWidth/3) + 7, y=(squareWidth/3) + 8)
square86 = Button(board8, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square86, board6, mini6))
square86.place(x=5, y=2*(squareWidth/3) + 7)
square87 = Button(board8, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square87, board7, mini7))
square87.place(x=int((squareWidth/3 + 6)), y=int(2*(squareWidth/3) + 7))
square88 = Button(board8, width=int(miniSquareWidth), height=int(miniSquareWidth - 3), image=Nonephoto, fg=defaultbg, bg=defaultbg, activeforeground=defaultbg, activebackground=defaultbg, bd=0, command=lambda: setXorO(whosTurn, square88, board8, mini8))
square88.place(x=2*(squareWidth/3) + 7, y=2*(squareWidth/3) + 7)



def exitGame():
	m.destroy()
exitButton = Button(m, text = "Close", command = exitGame)
exitButton.place(x=appHeight/6 + 15, y=appHeight/6 + 480)
restartButton = Button(m, text = "Restart", command = exitGame)
restartButton.place(x=appHeight/6 + 10, y=appHeight/6 + 520)

m.mainloop()


